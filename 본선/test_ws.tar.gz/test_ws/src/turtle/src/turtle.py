import rospy
import time
from geometry_msgs.msg import Twist
from obstacle_detector.msg import Obstacles
from ObstacleDetector import ObstacleDetector, Position

obstacles = None
def obstacle_callback(data):
    global obstacles
    obstacles = data

def move():
	rospy.init_node('my_node', anonymous=True)
	pub = rospy.Publisher('/turtle1/cmd_vel', Twist, queue_size = 10)

	obstacle_sub = rospy.Subscriber("/obstacles", Obstacles, obstacle_callback, queue_size = 1)

	msg = Twist()
	msg.linear.x = 2.0
	msg.linear.y = 0.0
	msg.linear.z = 0.0

	msg.angular.x = 0.0
	msg.angular.y = 0.0
	msg.angular.z = 1.8


	ob = ObstacleDetector()
	time.sleep(3)

	while not rospy.is_shutdown():
		ob.check(obstacles)
		print(ob.mode)

		if(ob.mode == Position.LEFT):
			msg.angular.z = 0.0
			msg.linear.x = 5.0
		else:
			msg.angular.z = 1.8
			msg.linear.x = 2.0
			
		pub.publish(msg)
		time.sleep(0.1)
		

if __name__ == '__main__':
	try:
		move()
	except rospy.ROSInterruptException:
		pass
